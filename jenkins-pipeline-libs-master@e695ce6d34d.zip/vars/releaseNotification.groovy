def call() {
    println "Sending release note.."
}