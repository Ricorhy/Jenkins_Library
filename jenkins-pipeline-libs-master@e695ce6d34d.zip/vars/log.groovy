def info(msg) {
    println "[INFO]: ${msg}"
}

def err(msg) {
    error "[ERROR]: ${msg}"
}