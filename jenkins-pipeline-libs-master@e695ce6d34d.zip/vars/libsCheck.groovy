def call() {
    println "You successfully loaded ADOP Pipeline libraries!"
}
